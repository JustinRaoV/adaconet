Paper title: Linking Long-Term Dietary Patterns with Gut Microbial Enterotypes
Authors: Gary D. Wu, Jun Chen, Christian Hoffmann, Kyle Bittinger, Ying-Yu Chen, 
Sue A. Keilbaugh, Meenakshi Bewtra, Dan Knights, William A. Walters, Rob Knight, 
Rohini Sinha, Erin Gilroy, Kernika Gupta, Robert Baldassano, Lisa Nessel, 
Hongzhe Li, Frederic D. Bushman, James D. Lewis

Paper: http://science.sciencemag.org/content/334/6052/105
Data: https://www.ncbi.nlm.nih.gov/Traces/study/?acc=SRP002424

The data was downloaded following the methods used in Sze and Schloss'
obesity meta-analysis. Specifically, I used code from their github:
https://github.com/SchlossLab/Sze_Obesity_mBio_2016/blob/master/code/wu.batch

DOWNLOADING DATA
----------------

## Download raw data

```
# Get *.sra files from the SRA
wget -r -np -nd -k -P raw_sra ftp://ftp-trace.ncbi.nih.gov/sra/sra-instant/reads/ByStudy/sra/SRP/SRP002/SRP002424/

# Convert to fastq
for f in raw_sra/*.fastq
do
fastq-dump $f -O raw_fastq/
done
```

Sze and Schloss concatenated all the files together, so I'll assume that they checked that barcodes were
unique to each fastq file and this is legit.

I checked this with one file, and it looks like the barcode for this file is only in that file.

```
# Should return nothing
grep ^TCAGACTCTGAG SRR327* | grep -v SRR327640
```

```
cat raw_fastq/*.fastq > SRP002424_concat.fastq
```

Looks like the barcodes (wu.oligos) are in the Schloss repo: 
https://github.com/SchlossLab/Sze_Obesity_mBio_2016/tree/master/data/wu/
I downloaded this file, and manipulated it into the format we need:

```python
import pandas as pd
df = pd.read_csv('wu.oligos', sep='\t', header=None, names=['barcode', 'seq', 'sample'])
newdf = df[['sample', 'seq']]
newdf.to_csv('wu.barcodes_map.txt', sep='\t', index=False, header=False)
```

And from the processing that Sze and Schloss did, doesn't seem like we need to
trim primers.

PROCESSING
----------

To recap, we have one concatenated fastq file with barcodes still in the sequences
and primers already trimmed. Note that the SRA data contains multiple studies,
but the Sze meta-analysis only used a subset of 64 samples. We'll do this as well
to avoid any headaches.

From here, straightfoward to use the pipeline.

METADATA
--------

Two metadata files were downloaded from the Schloss repo 
(https://github.com/SchlossLab/Sze_Obesity_mBio_2016/tree/master/data/wu)
bmi_info.txt and COMBO_data_table.csv.

It looks like COMBO_data_table.csv was acquired from an SRA-provided place,
and the bmi_info.txt was likely acquired from personal communication with the 
authors? Anyway, the COMBO table maps SRR file names to sample IDs, and the
bmi_info.txt has BMIs associated with those sample IDs. Let's merge these
into one file and use that as our ob_wu.metadata.txt.

```
import pandas as pd

# Read in BMI data
bmi = pd.read_csv('bmi_info.txt', sep=' ')
bmi.index.name = 'sample_id'
bmi = bmi.reset_index()
bmi['sample_id'] = bmi['sample_id'].astype(str)

# Read in SRA metadata
sra = pd.read_csv('COMBO_data_table.csv')

meta = pd.merge(bmi, sra, left_on='sample_id', right_on='submitted_subject_id_s', how='outer')
meta = meta.query('submitted_sample_id_s != "<not provided>"')
meta.index = meta['sample_id']
meta.to_csv('ob_wu.metadata.txt', sep='\t')
```

Note that there are more samples with BMI data (101 samples) than there are samples with
sequencing data (64 samples). This metadata file has NaN values for the Run_s column for
those samples without fastq data.
